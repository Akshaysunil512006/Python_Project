# Write a program to search a specific word in a string.

text = input("Enter a sentence: ")
search_word = input("Enter the word to search: ")

words = text.split()

if search_word in words:
    print(f"The word '{search_word}' was found in the string.")
else:
    print(f"The word '{search_word}' was NOT found in the string.")