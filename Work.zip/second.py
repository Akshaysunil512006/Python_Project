# Write a program to count the number of words in that sentence.

sentence = input("Enter a sentence: ")

words = sentence.split()#".split"for splitting the words
word_count = len(words)

print("Number of words in the sentence:", word_count)
