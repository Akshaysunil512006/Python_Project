# Program to count the occurrence of each character in a word

word = input("Enter a word: ")

char_count = {}

for char in word:
    if char in char_count:
        char_count[char] += 1
    else:
        char_count[char] = 1  

print("Character occurrences:")
for char, count in char_count.items():
    print(f"{char}: {count}")
