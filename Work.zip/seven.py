# Program to check if a string is a palindrome

text = input("Enter a string: ")

cleaned_text = text.replace(" ", "").lower()

reversed_text = cleaned_text[::-1]

if cleaned_text == reversed_text:
    print("The string is a palindrome.")
else:
    print("The string is not a palindrome.")
