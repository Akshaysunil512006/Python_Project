# Write a program to count the number of uppercase letters in the string.

A = input("Enter a string: ")
count = 0
for i in A:
    if i.isupper():
        count+=1

print("The number of Uppercase letters= ",count)