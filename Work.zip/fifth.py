# Program to replace all occurrences of 'a' with 'e'

text = input("Enter a string: ")

new_text = text.replace('a', 'e')

print("Modified string:", new_text)