# Write a program that converts all characters to uppercase.

A = input("Enter your name: ").upper()

print("Hello, ",A)