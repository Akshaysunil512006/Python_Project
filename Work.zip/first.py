# Write a program that takes a string as input and print its length.

A = input("Enter a string: ")
length = len(A)

print("The length of the string you entered: ",length)  