import tkinter as tk
from tkinter import filedialog, messagebox
import PyPDF2
import pytesseract
from PIL import Image
import sqlite3
import os

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def save_result(resume, result):
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS results(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            resume TEXT,
            result TEXT
        )
    """)
    cur.execute("INSERT INTO results (resume, result) VALUES (?,?)", (resume, str(result)))
    conn.commit()
    conn.close()

def extract_text(file_path):
    text = ""

    if file_path.endswith(".pdf"):
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text += page.extract_text()

    elif file_path.endswith((".jpg", ".jpeg", ".png")):
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image)

    return text.lower()

def extract_skills(text):
    skills = [
        "python","java","c++","html","css","javascript","sql",
        "machine learning","data analysis","excel","communication",
        "django","flask","react","node"
    ]
    found = [skill for skill in skills if skill in text]
    return found

def match_jobs(skills):
    jobs = {
        "Software Developer": ["python", "java", "c++"],
        "Web Developer": ["html", "css", "javascript"],
        "Data Analyst": ["python", "sql", "excel"],
        "Machine Learning Engineer": ["python", "machine learning"],
        "Backend Developer": ["python", "django", "flask"],
    }

    result = {}
    for job, req_skills in jobs.items():
        match = len(set(skills) & set(req_skills))
        score = int((match / len(req_skills)) * 100)
        if score > 0:
            result[job] = score

    return result

def upload_resume():
    file_path = filedialog.askopenfilename(
        filetypes=[("PDF Files", "*.pdf"), ("Image Files", "*.jpg *.png *.jpeg")]
    )

    if not file_path:
        return

    text = extract_text(file_path)
    skills = extract_skills(text)
    results = match_jobs(skills)

    output.delete("1.0", tk.END)
    output.insert(tk.END, "🔍 Recommended Job Roles\n\n")

    if not results:
        output.insert(tk.END, "No suitable job found.\n")
    else:
        for job, score in results.items():
            output.insert(tk.END, f"{job} : {score}% match\n")

    save_result(file_path, results)

root = tk.Tk()
root.title("AI Job Recommendation System")
root.geometry("650x550")
root.config(bg="#f2f2f2")

TITLE_FONT = ("Segoe UI", 20, "bold")
BTN_FONT = ("Segoe UI", 12, "bold")
TEXT_FONT = ("Consolas", 12)

tk.Label(root, text="AI Job Recommendation System",
         font=TITLE_FONT, bg="#f2f2f2").pack(pady=15)

tk.Button(root,
          text="Upload Resume",
          font=BTN_FONT,
          bg="#4CAF50",
          fg="white",
          width=20,
          command=upload_resume).pack(pady=10)

output = tk.Text(root, height=20, width=70, font=TEXT_FONT)
output.pack(pady=10)

root.mainloop()
